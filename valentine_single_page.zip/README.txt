# Valentine single-page

## What it does
- Shows: "Will you be my valentine?"
- Button NO: keeps shrinking and "runs away" (moves) on hover/touch/mousedown
- Button YES: keeps growing each time you try to press NO
- Clicking YES opens a small success modal

## Deploy (get a link)
### Fastest: Netlify Drop
1) Go to Netlify (Deploy manually / Drop)
2) Drag-and-drop the folder that contains `index.html`
3) You'll instantly get a public URL

### Cloudflare Pages
1) Create a project (upload or connect a Git repo)
2) Deploy as a static site (no build needed)
3) You'll get `https://<name>.pages.dev`

### GitHub Pages
1) Push `index.html` to a repo
2) Settings → Pages → Deploy from branch
3) URL will be `https://<user>.github.io/<repo>/`

## Add a Minion image
Place `minion.png` next to `index.html`, then uncomment:
`<img class="minion" src="./minion.png" alt="Minion with a heart" />`
and remove the emoji placeholder.
